package com.mandavee.employee.operation.service;

import java.util.ArrayList;
import java.util.List;

import com.mandavee.employee.operation.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mandavee.employee.operation.repository.EmployeeRepository;
//defining the business logic
@Service
public class EmployeeService
{
@Autowired
EmployeeRepository employeeRepository;
//getting all employee record by using the method findaAll() of CrudRepository
public List<Employee> getAllEmployee()
{
List<Employee> employees = new ArrayList<Employee>();
employeeRepository.findAll().forEach(employee1 -> employees.add(employee1));
return employees;
}
//getting a specific record by using the method findById() of CrudRepository
public Employee getEmployeeById(int id)
{
return employeeRepository.findById(id).get();
}
//saving a specific record by using the method save() of CrudRepository
public void saveOrUpdate(Employee employee)
{
employeeRepository.save(employee);
}
//deleting a specific record by using the method deleteById() of CrudRepository
public void delete(int id) 
{
employeeRepository.deleteById(id);
}
//updating a record
public void update(Employee employee, int bookid)
{
employeeRepository.save(employee);
}
}