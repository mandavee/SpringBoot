package com.mandavee.employee.operation.repository;
import com.mandavee.employee.operation.model.Employee;
import org.springframework.data.repository.CrudRepository;
//repository that extends CrudRepository

public interface EmployeeRepository extends CrudRepository<Employee, Integer>
{
}
